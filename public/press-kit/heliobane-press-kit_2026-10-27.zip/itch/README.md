# itch.io

`cover_630x500.png`: the cover of HELIOBANE (Amiga) on itch.io (coze.itch.io/heliobane-amiga), 630×500.
Made 2026-10-26 from `key-art/key_art_no_logo.png` at its native 480×270 (the key art is ×4): a 315×250
crop from x 175, y 7, right of the ship and centred on the sun-eye; the 10 columns past the art's right
edge are its last 10 columns mirrored. `logo/heliobane_logo_1x.png` centred over it 6 px from the top,
then the whole ×2 nearest-neighbour. No other resampling.
